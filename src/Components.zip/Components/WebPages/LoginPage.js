import React, { useState, useEffect } from 'react';
import axios from 'axios';
import sbilogo from './Media/sbilogo.png';
import styles from './Styles/LoginPage.module.css';
import cntLogo from './Media/contactlogo.png';
import userLogo from './Media/userLogo.jpg';
import { Link, useNavigate } from 'react-router-dom';


function LoginPage() {

    const mainDiv = {

        width: "80%",
        marginLeft: "10%",
        marginRight: "10%"

    }

    const header = {

        padding: "1.5%"

    }

    const navBar = {
        marginTop: "1.5%"
    }

    const [accNumber, inputAccountNumber] = useState()

    const [password, inputPassword] = useState()

    // const postData = () => {

    //     axios.post(`http://localhost:8084/login`, {
    //     accNumber
    //   })

    // }

    const [posts, setPosts] = useState({})


    // useEffect(() => {


    //     axios.get(`http://localhost:8084/getUser/${accNumber}`)


    //         .then(res => {

    //             console.log(res.data)
    //             setPosts(res.data)
    //             setLoading(false)

    //         })
    // }, [])

    const loginHandler = () => {

        axios.get(`http://localhost:8084/getUser/${accNumber}`)


            .then(res => {
                console.log(res.data)
                setPosts(res.data)
                validate(res.data);
            });


    }

    const [url, setUrl] = useState()

    const validate = (posts) => {
        console.log(posts)

        // for (var i = 0; i < posts.length; i++) {
        //     if (posts[i].accountNumber == accNumber) {
        //         if (posts[i].password == password) {
        //             navigateToDashboard()
        //         }
        //         else if (password == null) {
        //             setUrl("#popup2")
        //         }
        //         else {
        //             setUrl("#popup1")
        //         }
        //     }
        //     else if(accNumber== 0 && password == "admin")
        //     {
        //         navigateToAdminPage()
        //     }
        // }

        console.log(accNumber)
        console.log(password)

        if (accNumber == 0 && password == "admin") {
            navigateToAdminPage()
        }
        else if(posts.accountNumber == null)
        {
            alert("Account Not Found !")
        }
        else if(accNumber == null || password == null)
        {
            alert("All fields are required")
        }
        else {
            if (posts.password == password) {
                navigateToDashboard()
            }
            else if (password == null) {
                setUrl("#popup2")
            }
            else {
                setUrl("#popup1")
            }
        }

    }

    const navigate = useNavigate();

    const navigateToDashboard = () => {

        navigate('/Dashboard', { state: accNumber });
    };

    const navigateToAdminPage = () => {

        navigate('/adminPage', { state: accNumber });
    };



    return (



        <div style={mainDiv} >

            <div style={header} ><img src={sbilogo} align="left" alt="Logo" width={"9%"} height={"4%"} /></div>
            <br />
            <div style={navBar} >

                <div className={styles.navbar}>

                    <Link to="/home" >Home</Link>
                    <Link to="/howDoI" >How do I</Link>
                    <Link to="/contactUs" >Contact Us</Link>

                </div>

            </div>
            <div className={styles.alert}>

                <h5>NEVER respond to any popup,email, SMS or phone call, no matter how appealing or official looking, seeking your personal information such as username, password(s), mobile number, ATM Card details, etc. Such communications are sent or created by fraudsters to trick you into parting with your credentials.</h5>

            </div>
            <div className={styles.login} >

                <h5>(CARE: Password is case sensitive.)</h5>
                <h3>Account Number*</h3>
                <input type="number" placeholder="Account Number" onChange={(e) => { inputAccountNumber(e.target.value) }} className={styles.input} />
                <br />
                <h3>Password*</h3>
                <input type="password" placeholder="Password" onChange={(e) => { inputPassword(e.target.value) }} className={styles.input} />
                <br />
                <a href={url}><button onClick={loginHandler} className={styles.loginBTN}>Log In</button></a>

                <br /><br />
                <Link to="/createAccount" >New User ? Register here</Link>
                <br /><br />
                <Link to="/changePass" >Forgot Login Password</Link>
                <br /><br />

            </div>
            <div id="popup1" className={styles.overlay}>
                <div className={styles.popup}>
                    <br /><br /><br />
                    <h2>Invalid Password</h2>
                    <a className={styles.close} href="#">&times;</a>
                    <br />
                    <a href='#'><button className={styles.loginBTN} >Ok</button></a>
                </div>
            </div>
            <div id="popup2" className={styles.overlay}>
                <div className={styles.popup}>
                    <br /><br /><br />
                    <h2>Fill all required feilds.</h2>
                    <a className={styles.close} href="#">&times;</a>
                    <br />
                    <a href='#'><button className={styles.loginBTN} >Ok</button></a>
                </div>
            </div>
            <div>
                <ul>
                    <li><h5>Mandatory fields are marked with an asterisk (*)</h5></li>
                    <li><h5>Do not provide your account number and password anywhere other than in this page</h5></li>
                    <li><h5>Your credentials are highly confidential. Never part with them.SBI will never ask for this information.</h5></li>
                </ul>
            </div>


        </div>
    )
}

export default LoginPage
